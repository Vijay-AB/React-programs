//import logo from './logo.svg';
import './App.css';
import HookCounterOne from './useeffect';

function App() {
  return (
    <HookCounterOne/>
  );
}

export default App;
