import { render, screen } from '@testing-library/react';
import App from './App';
import HelloWorld from './HelloWorld';

test('test scenario 1', () => {
  render(<HelloWorld />);
  const element = screen.getByText(/Hello World/i);
  expect(element).toBeInTheDocument();
});

test('renders learn react link', () => {
  render(<App />);
  const linkElement = screen.getByText(/learn react/i);
  expect(linkElement).toBeInTheDocument();
});
