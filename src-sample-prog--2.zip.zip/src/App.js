//import logo from './logo.svg';
import './App.css';
//import Counter from './counter';
import Counterusememo from './counterusememo';

function App() {
  return (
    //<Counter/>
    <Counterusememo/>
  );
}

export default App;
