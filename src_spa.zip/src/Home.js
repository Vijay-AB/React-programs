import React, { Component } from "react";

class Home extends Component {
  render() {
    return (
      <div>
        <h3>SPA App - Home</h3>
        <p>This is a paragraph on the HomePage of the SPA App.</p>
      </div>
    );
  }
}

export default Home;