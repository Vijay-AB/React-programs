
import './App.css';
import UserComponent from './UserComponent';


function App() {
  return (
    <UserComponent/>
  );
}

export default App;
