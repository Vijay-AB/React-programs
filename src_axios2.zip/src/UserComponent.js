import React from "react";

const UserComponent = props => {
  const [email, setEmail] = React.useState("");
  React.useEffect(() => {
    const fetchUserEmail = async () => {
      const response = await fetch("/emails");
      const { email } = await response.json();
      setEmail(email);
    };
    fetchUserEmail();
  }, []);

  return (
    <div>
      <h1>A user</h1>
      <p>{email}</p>
    </div>
  );
};

export default UserComponent;