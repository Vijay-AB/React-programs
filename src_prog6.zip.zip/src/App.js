
import './App.css';
import ChildComponent from './ChildComponent';
import PageNameContext from './PageNameContext';
import ParentPage from './ParentPage';

function App() {
  return (
    <div>
      <PageNameContext/>
      <ParentPage/>
      <ChildComponent/> 
    </div>
  );
}

export default App;
