import ChildComponent from "./ChildComponent";
import PageNameContext from "./PageNameContext";

const ParentPage = () => (
  <PageNameContext.Provider value="ParentPage">
    <h1>Parent page title</h1>
    <ChildComponent />
  </PageNameContext.Provider>
);

export default ParentPage;