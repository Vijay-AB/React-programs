import { createContext } from 'react';

const PageNameContext = createContext();

export default PageNameContext;