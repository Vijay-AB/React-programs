//import logo from './logo.svg';
import './App.css';
import Samplereducer from './testreducer';

function App() {
  return (
     <Samplereducer/>
  );
}

export default App;
