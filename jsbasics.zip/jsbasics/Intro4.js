//function definition
<script>
  function fun()
   {  document.write("Hi, I am from outside!")
     }
</script>