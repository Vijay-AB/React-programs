import PostForm from './postform4';
import './App.css';

function App() {
    <PostForm/>
}

export default App;
