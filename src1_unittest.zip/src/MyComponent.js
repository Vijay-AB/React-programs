import React from 'react';

export default function MyComponent() {
    return <div id = "my-component">Hello, World</div>;
  }