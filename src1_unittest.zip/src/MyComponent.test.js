import React from 'react';
import { render } from '@testing-library/react';
import MyComponent from './MyComponent';


test('renders MyComponent without errors', () => 
{
 render(<MyComponent />);
 //const componentElement = screen. //getByTestId('my-component');
 expect(componentElement).toBeInTheDocument();
}
);

/* describe('MyComponent', () => 
  {
    it('renders correctly', () => 
    {
      const { getByText } = render(<MyComponent />);
      const linkElement = getByText(/Hello World/i);
      expect(linkElement).toBeInTheDocument();
    });
  }); */
  /* test('test scenario 1', () => {
    render(<HelloWorld />);
    const element = screen.getByText(/Hello World/i);
    expect(element).toBeInTheDocument();
 }); */