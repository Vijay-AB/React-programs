
import './App.css';
import AppForm1 from './form1';
import Parent from './parent';

function App() {
  return (
    <div>
     <Parent/>
     <AppForm1/>
    </div>
  );
}

export default App;
