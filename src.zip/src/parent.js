
import Child from "./child";
function Parent()
{
    return(
        <div> <p> This message is from parent component </p>
                <Child/> 
        </div>
    );
}

export default Parent