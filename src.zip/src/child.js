function Child()
{
    return(
        <div>
            <p> This message is from child component </p>
        </div>
    )
}
export default Child