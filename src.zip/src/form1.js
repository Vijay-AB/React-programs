function AppForm1()
{
    return(
        <div>
            <h3> Enter Emp Data </h3>
            <form name="Empform" method="GET">
                <label for empId>
                    Enter Employee Id:
                       <input type="text" name="empId" required/>
                </label>
                <br/>
                <label for empName>
                    Enter Employee Name:
                       <input type="text" name="empName" required/>
                </label>
                <br/>
                <label for empSal>
                    Enter Employee Salary:
                       <input type="text" name="empSal" required/>
                </label>
                <br/>
                     <input type="submit" value="Submit Here"/>
            </form>
        </div>
    )
}
export default AppForm1