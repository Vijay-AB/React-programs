//import logo from './logo.svg';
import './App.css';
import ParentComponent from './parent';

function App() {
  return (
    <ParentComponent/>
  );
}

export default App;
