function ChildComponent({ onClick }) {
    return (
      <button onClick={onClick}>Increment</button>
    );
  }
  export default ChildComponent