import React from 'react'

const Signin = () => { 
    return( <div>
               <div>
                  <button type="button">Sign Out</button>
                  <p>Welcome back, good to see you in here</p>
               </div>  
               <div>
                  <button type="button">Sign In</button>
                  <p>Please Sign in</p>
               </div>
            </div>
         );
 }
export default Signin