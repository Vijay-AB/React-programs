import React, { useState }from 'react'

const Theform = () => 
    {
        const [user, setUser] = useState('')
        const [email, setEmail] = useState('')
        const [salary, setSalary] = useState('')
        const handleSubmit = (e) => { e.preventDefault()
                                      console.log(user, email)
                                    }
        return (
        <div>
           <form onSubmit={handleSubmit}>
            <input type="text" onChange={(e) => {setUser(e.target.value)}} value ={user} required />
            <input type="email" onChange={(e) => {setEmail(e.target.value)}} value={email} required />
            <input type="salary" onChange={(e) => {setSalary(e.target.value)}} value={salary} required />
            <button type="submit">Submit</button>
        </form>
    </div>
  )
}

export default Theform;