
import './App.css';
//import Counter from './Counter._useState';
//import Signin from './SignIn';
//import Signin_useState from './SignIn_useState';
import Theform from './form1_usestate';

function App() {
  return (
    // <Signin/>
   // <Signin_useState/>
   //<Counter/>
   <Theform/>

  );
}

export default App;
