import React from "react"

function Welcome()
{
    return(
        <div>
            <p> Its Welcome from React team !</p>
            <table border='1'>
                <tr>
                    <th>Sl.No.</th>
                    <th>Name</th>
                    <th>City</th>
                </tr>
            </table>
        </div>
    )
}

export default Welcome;