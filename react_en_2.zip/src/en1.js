import React from "react"

function Hello()
{
    return(
       <> <div> 
            <h3>Welcome to React Session !</h3>
              <p>We are in post-tea session @Panther</p>
        
        </div> </>
    )
}

export default Hello
